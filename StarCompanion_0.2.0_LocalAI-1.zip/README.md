# 星伴 Star Companion 0.2.0

本版加入 `.litertlm` 文件选择、复制到应用专属 `files/models/` 目录、LiteRT-LM Engine 初始化，以及基于 Conversation 的本地对话。

## 构建
JDK 17、Gradle 9.4.0、Android Gradle Plugin 9.3.1、Kotlin Android plugin 2.4.0、compileSdk 36、minSdk 24。

GitHub 仓库已配置 Actions 时，将本包内容解压后上传并覆盖仓库根目录文件（包括 `.github/workflows/android.yml`），再运行 Actions。成功后从 Artifacts 下载 APK。

## 模型导入
安装 APK 后点“导入 Qwen 模型”，从系统文件选择器选取已下载的 `.litertlm` 文件。应用会复制到：
`/data/user/0/com.starcompanion.app/files/models/qwen.litertlm`
该目录属于应用私有目录，无需在文件管理器中手动寻找。

## 重要限制
- 此源码按 Google LiteRT-LM Android API 编写，但本次环境没有 Android SDK/Gradle 构建环境，尚未实际编译或真机验证。GitHub Actions 的构建结果才是编译验证。
- 模型文件必须与 LiteRT-LM 运行时兼容；若模型加载失败，可能是模型格式/模板/设备后端兼容问题。
- 本版使用 CPU 默认后端；首轮加载会比较慢。聊天在单线程后台执行。
- 角色设定在创建 Conversation 时注入。更改设定后需重新加载模型才会应用。
- 这是最小本地聊天版，暂未实现 Galgame 立绘渲染、长期记忆摘要、语音或微信消息发送。
