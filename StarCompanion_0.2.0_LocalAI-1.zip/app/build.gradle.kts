plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.starcompanion.app"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.starcompanion.app"
        minSdk = 24
        targetSdk = 28
        versionCode = 2
        versionName = "0.2.0"
    }
}
dependencies {
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.18.0")
}
