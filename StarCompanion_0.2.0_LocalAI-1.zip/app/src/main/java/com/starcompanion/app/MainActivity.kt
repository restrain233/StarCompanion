package com.starcompanion.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.*
import android.view.ViewGroup
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Contents
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private var engine: Engine? = null
    private var conversation: Conversation? = null
    private lateinit var status: TextView
    private lateinit var chatLog: TextView
    private lateinit var input: EditText
    private lateinit var roleName: EditText
    private lateinit var rolePrompt: EditText
    private val prefs by lazy { getSharedPreferences("star", MODE_PRIVATE) }
    private val pickModel = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        val title = TextView(this).apply { text = "星伴 Star Companion"; textSize = 24f }
        status = TextView(this).apply { text = "尚未导入模型"; textSize = 14f }
        roleName = EditText(this).apply {
            hint = "角色名字"; setText(prefs.getString("name", "星伴"))
        }
        rolePrompt = EditText(this).apply {
            hint = "角色性格设定"; minLines = 2
            setText(prefs.getString("prompt", "温柔、自然、善于倾听的中文陪伴伙伴。"))
        }
        val import = Button(this).apply {
            text = "导入 Qwen 模型（.litertlm）"
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(i, pickModel)
            }
        }
        val saveRole = Button(this).apply {
            text = "保存角色设定"
            setOnClickListener {
                prefs.edit().putString("name", roleName.text.toString())
                    .putString("prompt", rolePrompt.text.toString()).apply()
                Toast.makeText(this@MainActivity, "角色设定已保存", Toast.LENGTH_SHORT).show()
            }
        }
        chatLog = TextView(this).apply { text = "欢迎来到星伴。导入模型并加载后即可离线聊天。\n"; textSize = 16f }
        val scroll = ScrollView(this).apply { addView(chatLog) }
        input = EditText(this).apply { hint = "输入消息…" }
        val send = Button(this).apply {
            text = "发送"
            setOnClickListener { sendMessage() }
        }
        box.addView(title)
        box.addView(status)
        box.addView(roleName)
        box.addView(rolePrompt)
        box.addView(saveRole)
        box.addView(import)
        box.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        box.addView(input)
        box.addView(send)
        setContentView(box)
    }

    @Deprecated("Deprecated in Android API but retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickModel || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        status.text = "正在复制模型…"
        worker.execute {
            try {
                val models = File(filesDir, "models").apply { mkdirs() }
                val modelFile = File(models, "qwen.litertlm")
                contentResolver.openInputStream(uri).use { src ->
                    requireNotNull(src) { "无法读取所选文件" }.copyTo(modelFile.outputStream())
                }
                runOnUiThread {
                    status.text = "模型已导入，正在加载…"
                }
                loadModel(modelFile)
            } catch (e: Exception) {
                runOnUiThread { status.text = "导入失败：${e.message}" }
            }
        }
    }

    private fun loadModel(file: File) {
        worker.execute {
            try {
                val newEngine = Engine(EngineConfig(modelPath = file.absolutePath))
                newEngine.initialize()
                val prompt = rolePrompt.text.toString().ifBlank { "你是一个温柔自然的中文陪伴伙伴。" }
                val conv = newEngine.createConversation(
                    ConversationConfig(systemInstruction = Contents.of(prompt))
                )
                engine = newEngine
                conversation = conv
                runOnUiThread { status.text = "模型已加载，可以离线聊天"; append("系统", "Qwen 模型加载成功。") }
            } catch (e: Exception) {
                runOnUiThread { status.text = "模型加载失败：${e.message}" }
            }
        }
    }

    private fun sendMessage() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        append("我", text)
        worker.execute {
            try {
                val conv = conversation ?: throw IllegalStateException("请先导入并加载模型")
                val answer = conv.sendMessage(text).toString()
                runOnUiThread { append(roleName.text.toString().ifBlank { "星伴" }, answer) }
            } catch (e: Exception) {
                runOnUiThread { append("提示", e.message ?: "发生错误") }
            }
        }
    }

    private fun append(who: String, text: String) {
        chatLog.append("\n$who：$text\n")
    }

    override fun onDestroy() {
        worker.execute {
            try { conversation?.close() } catch (_: Exception) {}
            try { engine?.close() } catch (_: Exception) {}
            conversation = null; engine = null
        }
        worker.shutdown()
        super.onDestroy()
    }
}
