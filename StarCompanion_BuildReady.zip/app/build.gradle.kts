plugins { id("com.android.application") }
android { namespace = "com.starcompanion.app"; compileSdk = 35
 defaultConfig { applicationId = "com.starcompanion.app"; minSdk = 24; targetSdk = 28; versionCode = 1; versionName = "0.1.0" } }
