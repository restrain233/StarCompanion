# 星伴 Star Companion（原型）

这是 Android 原生 Java 原型源码，包含普通聊天 / Galgame 模式切换、角色设定、相册图片选择入口和本地聊天记录。

**重要：当前版本尚未接入 AI 推理模型。** 它可以构建为 APK，但不会生成真正的 AI 回复。此包也不是现成 APK。

## 尽量少操作地生成 APK（使用 GitHub Actions）

1. 在 GitHub 新建一个空仓库。
2. 将本压缩包解压后的所有文件（包括隐藏的 `.github` 文件夹）上传到仓库根目录。
3. 打开仓库的 **Actions** 页面，选择 **Build StarCompanion APK**，点击 **Run workflow**。
4. 构建完成后，打开该次运行页面，在 **Artifacts** 下载 `StarCompanion-debug`，解压后安装 `app-debug.apk`。

首次安装时，Android 可能要求允许该来源安装应用。

## 构建环境

- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- compileSdk 35 / minSdk 24

## 当前限制

- 未集成 Qwen 或其他本地模型。
- 当前聊天只保存消息，不会产生真实 AI 回复。
- 角色图片选择目前保存 URI，尚未完成头像/立绘显示。
- 本源码未在真机上验证；GitHub Actions 构建成功后仍需在手机测试。
